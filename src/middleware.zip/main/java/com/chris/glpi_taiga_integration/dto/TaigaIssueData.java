package com.chris.glpi_taiga_integration.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public record TaigaIssueData(
        Long id,
        Long ref,
        String subject,
        String description,
        TaigaStatusData status,
        @JsonProperty("due_date") String dueDate,
        @JsonProperty("promoted_to") List<Long> promotedTo,
        @JsonProperty("generated_from_issue") Long generatedFromIssue
) {}
